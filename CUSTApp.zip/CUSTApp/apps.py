from django.apps import AppConfig


class CustappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CUSTApp'
